
  function checkEmail() {
  const InputEmail = document.getElementById("email");
  if (!validateEmail(InputEmail.value)) {
    alert("Please enter valid email address end with @edcil.co.in");
    InputEmail?.focus();
  }
}

function validateEmail(email) {
  const EmailRegex = /^[a-zA-Z0-9_.-]+@edcil\.co.in$/;
  return EmailRegex.test(email);
}

// for mobile number
function checkPhoneNumber() {
  const mobileInput = document.getElementById("mobile");
  if (!validateIndianPhoneNumber(mobileInput.value)) {
    alert("Please enter a valid 10-digit Phone number \nStarting with (6,7,8,9)");
    mobileInput?.focus();
    mobileInput.value = "";
  }
}
function validateIndianPhoneNumber(phoneNumber) {
  const PhoneRegex = /^[6-9]\d{9}$/;
  return PhoneRegex.test(phoneNumber);
}

function checkPassword() {
  var password = document.getElementById("pswd").value;
  var confirmPassword = document.getElementById("pswd1").value;

  // Check password format
  var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/;
  if (!passwordRegex.test(password)) {
      alert("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one number.");
      return false;
  }

  // Check password and confirm password match
  if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return false;
  }

  // Passwords match and are valid
  return true;
}


// for Password
// function checkPassword() {
//   const inputPassword = document.getElementById("pswd");
//   if (!validatePassword(inputPassword.value)) {
//     alert("Please Enter a strong password containing atleast \n One capital letter \n One special character[@,_] \n One digit");
//   }
// }
// function checkPassword() {
//   const inputPassword = document.getElementById("pswd1");
//   if (!validatePassword(inputPassword.value)) {
   
   
//     // alert("Please Enter a strong password containing atleast \n One capital letter \n One special character[@,_] \n One digit");
//   }
// }
// function validatePassword(password) {
//   const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[@_])(?=.*\d)[a-zA-Z0-9@_]{8,}$/;
//   return regex.test(password);
// }

// function checkPassword1() {
//   var password = document.getElementById("pswd").value;
//   var confirmPassword = document.getElementById("pswd1").value;

//   if (password !== confirmPassword) {
//       alert("Passwords not matching.");
//       return false;
//   }

//   // Passwords match
//   return true;
// }

