function validateEmail() {
    var email = document.getElementById("email").value;

    // Check email format using regular expression
    var emailRegex =  /^[a-zA-Z0-9_.-]+@edcil\.co.in$/;
    if (!emailRegex.test(email)) {
        alert("Invalid email address.");
        return false;
    }

    // Email is valid
    return true;
}

function validatePhoneNumber() {
    var phoneNumber = document.getElementById("mobile").value;

    // Remove any non-digit characters from the phone number
    var cleanedPhoneNumber = phoneNumber.replace(/\D/g, '');

    // Check phone number format
    var phoneNumberRegex = /^[6-9]\d{9}$/;
    if (!phoneNumberRegex.test(cleanedPhoneNumber)) {
        alert("Invalid phone number. Please enter a 10-digit phone number.");
        return false;
    }

    // Phone number is valid
    return true;
}

function validatePassword() {
    var password = document.getElementById("pswd").value;
    var confirmPassword = document.getElementById("pswd1").value;
  
    // Check password format
    var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/;
    if (!passwordRegex.test(password)) {
        alert("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one number.");
        return false;
    }
  
    // Check password and confirm password match
    if (password !== confirmPassword) {
        alert("Passwords not matching.");
        return false;
    }
  
    // Passwords match and are valid
    return true;
  }

function validateForm() {
    // Call the email, phone number, and password validation functions
    var isEmailValid = validateEmail();
    var isPhoneNumberValid = validatePhoneNumber();
    var isPasswordValid = validatePassword();

    // Check if all validations pass
    if (isEmailValid && isPhoneNumberValid && isPasswordValid) {
        return true; // Form submission allowed
    } else {
        return false; // Form submission prevented
    }
}
function validateForm1(){
    var isEmailValid = validateEmail();
    var isPhoneNumberValid = validatePhoneNumber();
    if (isEmailValid && isPhoneNumberValid) {
        return true; // Form submission allowed
    } else {
        return false; // Form submission prevented
    }
}
function validateForm3() {
    var isPasswordValid = validatePassword();

    // Check if all validations pass
    if (isPasswordValid) {
        return true; // Form submission allowed
    } else {
        return false; // Form submission prevented
    }
}
function validateForm4() {
    var isEmailValid = validateEmail();

    // Check if all validations pass
    if (isEmailValid) {
        return true; // Form submission allowed
    } else {
        return false; // Form submission prevented
    }
}
function confirmRedirect() {
    if (confirm('Want to Resend Link to Update Password\n Click Ok to Confirm?')) {
      window.location.href = 'forgotpassword.php';
      return;
    }}
function  myFunction() {
    var x = document.getElementById("pswd");
    var y=document.getElementById("pswd1");
    
    if (x.type === "password" && y.type==="password") {
        x.type = "text";
        y.type="text";
    } else {
        x.type ="password";
        y.type="password";
    }
    }

function  myFunction1() {
    var x = document.getElementById("pswd");
    // var y=document.getElementById("pswd1");
    
    if (x.type === "password") {
        x.type = "text";
        // y.type="text";
    } else {
        x.type = "password";
        // y.type="password";
    }
    }
   