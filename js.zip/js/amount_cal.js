function calculatePaymentAmount(percentage, projectValue) {
        return parseFloat((percentage / 100) * projectValue).toFixed(2);
    }

 
console.log(projectValue);

    const liveperInput = document.getElementById("liveper");
    const admitperInput = document.getElementById("admitper");
    const cbtperInput = document.getElementById("cbtper");
    const resperInput = document.getElementById("resper");
    
    const livepymntInput = document.getElementById("livepymnt");
    const admitpymntInput = document.getElementById("admitpymnt");
    const cbtpymntInput = document.getElementById("cbtpymnt");
    const respymntInput = document.getElementById("respymnt");

    function updatePaymentInputs() {
        let liveper = parseFloat(liveperInput.value) || 0;
        let admitper = parseFloat(admitperInput.value) || 0;
        let cbtper = parseFloat(cbtperInput.value) || 0;
        let resper = parseFloat(resperInput.value) || 0;

        const totalPercentage = liveper + admitper + cbtper + resper;

        if (totalPercentage > 100) {
            // If total percentage is greater than 100, show an error message and reset the inputs
            alert("Total percentage cannot exceed 100%");
          
            resperInput.value = "";
            return;
        }
        
        if (totalPercentage !== 100 && resperInput === document.activeElement) {
            // If total percentage is less than 100 and user is editing the resperInput, show an error message
            // resperInput.value = "";
            alert("Total percentage must be 100%");
            return;
        }

        // resper = 100 - (liveper + admitper + cbtper);
        // resperInput.value = resper.toFixed(2);
       

        livepymntInput.value = calculatePaymentAmount(liveper, projectValue);
        admitpymntInput.value = calculatePaymentAmount(admitper, projectValue);
        cbtpymntInput.value = calculatePaymentAmount(cbtper, projectValue); 
        respymntInput.value = calculatePaymentAmount(resper, projectValue);
    }

    liveperInput.addEventListener("input", updatePaymentInputs);
    admitperInput.addEventListener("input", updatePaymentInputs);
    cbtperInput.addEventListener("input", updatePaymentInputs);
    resperInput.addEventListener("input", updatePaymentInputs);

 function calculateTotal() {
    var livePymnt = parseFloat(document.getElementById("livepymntrcvd").value) || 0;
    var admitPymnt = parseFloat(document.getElementById("admitpymntrcvd").value) || 0;
    var cbtPymnt = parseFloat(document.getElementById("cbtpymntrcvd").value) || 0;
    var resultPymnt = parseFloat(document.getElementById("respymntrcvd").value) || 0;
    
    var totalPymnt = livePymnt + admitPymnt + cbtPymnt + resultPymnt;
    // var actualProjValue = parseFloat(document.getElementById("actprojval").value) || 0;
    
    if (totalPymnt > projectValue) {

        alert("Total payment received cannot exceed actual project value.");
       totalPymnt.value= "";
        return;
    }
    
    document.getElementById("amountrcvd").value = totalPymnt.toFixed(2);
}
function totinvamt(){
    var invamtlive=parseFloat(document.getElementById("invamtlive").value)||0;
    var invamtadmit=parseFloat(document.getElementById("invamtadmit").value)||0;
    var invamtcbt=parseFloat(document.getElementById("invamtcbt").value)||0;
    var invamtres=parseFloat(document.getElementById("invamtres").value)||0;

    var totinvraise= invamtlive+ invamtadmit+invamtcbt+invamtres;
    if(totinvraise>projectValue){
        alert("Exceeding the project value.");
       totinvraise.value = "";
        return;
    }

    document.getElementById("invraise").value=totinvraise.toFixed(2);
}

function outstnd(invraiseId, amountrcvdId, outstndId) {
    var invraised = parseFloat(document.getElementById(invraiseId).value) || 0;
    var amountrcvd = parseFloat(document.getElementById(amountrcvdId).value) || 0;

    var totoutstnd = invraised - amountrcvd;
    document.getElementById(outstndId).value = totoutstnd.toFixed(2);
}
