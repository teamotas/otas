<?php 
function formatDate($date) {
    if (empty($date) || $date === "0000-00-00") {
        return "Not Declared"; // Return an empty string if the date is empty, null, or "0000-00-00"
    }

    // Define an array of month names
    $months = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");

    // Parse the input date string into a PHP date object
    $dateObj = date_create($date);

    // Extract year, month, and day
    $year = date_format($dateObj, 'Y');
    $monthIndex = date_format($dateObj, 'n') - 1; // Adjust for 0-based indexing
    $monthAbbreviation = $months[$monthIndex];
    $day = date_format($dateObj, 'd');

    // Assemble the formatted date string
    $formattedDate = $day . ' ' . $monthAbbreviation . ' ' . $year;

    return $formattedDate;
}


?>
