function calculateEndDate() {
    const startDateInput = document.getElementById("startDate");
    const endDateInput = document.getElementById("endDate");
    const durationInput = document.getElementById("duration");

    if (startDateInput.value && durationInput.value) {
            const startDate = new Date(startDateInput.value);
            const endDate = new Date(startDate);
            endDate.setDate(startDate.getDate() + parseInt(durationInput.value));
        
            const formattedEndDate = formatDate(endDate);
            endDateInput.value = formattedEndDate;
        } else {
            endDateInput.value = "";
        }
}
function formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// function formatDate(date) {
//     const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    
//     const year = date.getFullYear();
//     const monthIndex = date.getMonth();
//     const monthAbbreviation = months[monthIndex];
//     const day = date.getDate().toString().padStart(2, '0');
    
//     return `${day} ${monthAbbreviation} ${year}`;
// }

// // Example usage:
// const inputDate = new Date('2023-10-11');
// const formattedDate = formatDate(inputDate);
// console.log(formattedDate); // Output: "11 Oct 2023"


 // function formatDate(date) {
//     const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    
//     const year = date.getFullYear();
//     const monthIndex = date.getMonth();
//     const monthAbbreviation = months[monthIndex];
//     const day = date.getDate().toString().padStart(2, '0');
    
//     return `${day} ${monthAbbreviation} ${year}`;
// }

// // Example usage:
// const inputDate = new Date('2023-10-11');
// const formattedDate = formatDate(inputDate);
// console.log(formattedDate); // Output: "11 Oct 2023" -->

function calculateEstProjVal() {
    // Get the values from the input fields
    const ratePerCand = parseFloat(document.getElementById('percandrate').value);
    const expectedCount = parseFloat(document.getElementById('expcandcount').value);
    const actualCount = parseFloat(document.getElementById('actualcandcount').value);
    const estProjValInput = document.getElementById('estprojval');
    const actProjValInput = document.getElementById('actprojval');

    // Check if both inputs have valid numbers
    if (!isNaN(ratePerCand) && !isNaN(expectedCount)) {
        // Calculate the estimated project value (ratePerCand * expectedCount)
        const estProjVal = ratePerCand * expectedCount;

        // Display the calculated value with two decimal places
        estProjValInput.value = estProjVal.toFixed(2);
    } else {
        // Clear the estimated project value input if either input is not a valid number
        estProjValInput.value = '';
    }

    
    if (!isNaN(ratePerCand) && !isNaN(actualCount)) {
        // Calculate the estimated project value (ratePerCand * expectedCount)
        const actProjVal = ratePerCand * actualCount;

        // Display the calculated value with two decimal places
        actProjValInput.value = actProjVal.toFixed(2);
    } else {
        // Clear the estimated project value input if either input is not a valid number
        actProjValInput.value = '';
    }
}

// const selectBox = document.querySelector('.select');
// const selectList = document.querySelector('.select-list');
// const selectInput = document.querySelector('.input');
// const dropdown = document.querySelector('.dropdown-select');
// const dropdownicon= document.querySelector('.dropdown-icon1')
// const checkboxes = selectList.querySelectorAll('input[type="checkbox"]');

// selectBox.addEventListener('click', (event) => {
//   selectList.classList.toggle('open');
//   dropdown.classList.toggle('open');
//   dropdownicon.classList.toggle('open');
// });

// selectList.addEventListener('click', (event) => {
//   event.stopPropagation();

//   if (event.target.value === 'all') {
//     checkboxes.forEach(checkbox => {
//       checkbox.checked = event.target.checked;
//     });
//   } else if (event.target !== selectList) {
//     // selectInput.children[0].textContent = event.target.textContent;
//     selectList.classList.remove('open');
//   }
// });



// document.addEventListener('click', (event) => {
//   const selectBox = document.querySelector('.select');
//   const selectList = document.querySelector('.select-list');

//   if (!selectBox.contains(event.target) && !selectList.contains(event.target)) {
//     selectList.classList.remove('open');
//   }
// });
        


    
  
